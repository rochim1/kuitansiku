<script>

// $(window).scroll(function() {
//     scrolldist = $(window).scrollTop();
//     var height = $("#features").offset();
//     x = height.top - scrolldist;
	
//     if(x <= 0 )
//     {
//           $("body").addClass(' overflow-hidden');
//           $('.fullpage').fullpage({
//             onLeave: function(index, nextIndex, direction) {
//                 var leavingSection = $(this);
//                 requestAnimFrame(function(){
//                   console.log(nextIndex);
//                     if (nextIndex.isLast && direction == 'down') {   
//                         $("body").removeClass(' overflow-hidden');
//                         $.fn.fullpage.fadingEffect.turnOff();
//                         // $(this).scroll(function() {
//                         //   $('html, body').animate({
//                         //         scrollTop: $("#testimoni").offset().top
//                         //     }, 1000);
//                         // });
						
//                     }
//                 });
//             }
//           });

//     } 
// });

//     var biggestHeight = "0";
// $("#flex-box *").each(function(){
//  if ($(this).height() > biggestHeight ) {
//   biggestHeight = $(this).height();
//  }
// });
// $("#flex-box").height(biggestHeight);
</script>