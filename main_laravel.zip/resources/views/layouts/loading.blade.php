<style>
    * {
        background: red;
        padding: 0;
        margin: 0;
    }

    a {
        text-decoration: none;
        color: #333;
    }

    body {
        backgraund: #fff;
    }

    iframe {
        margin: 20px 0;
    }

    h1 {
        text-align: center;
    }

    h2 {
        margin: 15px 0;
        line-height: 1em;
        font-size: 17px;
    }

    p {
        margin: 10px 0;
    }

    #loading {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: red;
    }

    .container {
        width: 730px;
        margin: 0 auto;
        padding: 20px;
        background: #fff;
    }

    header {}

    .content img {
        width: 240px;
        height: 200px;
    }
</style>

<!-- jQuery Plugin -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js"></script>

<!-- Preloader -->
