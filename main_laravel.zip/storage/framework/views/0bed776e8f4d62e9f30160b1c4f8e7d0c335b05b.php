<html>
<head>
    <title><?php echo e($id); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/image/logo.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/team.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/header.css')); ?>">
    <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet"> 

    <script src=" <?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
    <script src=" <?php echo e(asset('lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <style>
    #header{
      background:#fff
    }
    body{
      padding-top:60px;
    }</style>
</head>
<body>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('menu/'.$id, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<footer class="page-footer font-small blue">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 
    <a href="https://mdbootstrap.com/education/bootstrap/"> Kuitansiku.com</a>
  </div>
  <!-- Copyright -->

</footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\main_laravel\resources\views/menu/main.blade.php ENDPATH**/ ?>