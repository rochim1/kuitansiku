<?php $__env->startSection('title', 'Kuitansiku'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>alert("this web is underconstruct);</script>
<div id="flex-box" >
  <div id="particles-js"></div>
  <section id="intro">
    <div class="container d-flex h-100">
      <div class="container d-flex h-100">
        <div class="row align-self-center">
          <div class=" col-md-6 intro-info order-md-first order-last">
            <div class="pointer_true">
              <h2>Aplikasi Kasir<br>Point of Sale</h2>
              <p>Pesatkan usahamu bersama sistem Point of Sale dari Kuitansiku, dengan berbagai fitur yang canggih dan bersahabat
              menjadikanmu mudah mengelola usaha.</p>
              <div>
                <a href="/user/log" class="btn-get-started scrollto">Coba Sekarang</a>
              </div>
            </div>
          </div>
          <div class="wow fadeInRight img-container col-md-6 intro-info order-md-first order-last" style="position:relative">
              
            <img class="img-fluid-komputer pull-right" src="<?php echo e(asset('assets/image/komputer.svg')); ?>"  alt="" >
            
            <img class="tablet img-fluid-phone" data-wow-delay="0.8s" src="<?php echo e(asset('assets/image/hp-real-1.svg')); ?>" alt="" style="right:5%;position: absolute;bottom:0px;">
            
            <img class="printer img-fluid-printer" data-wow-delay="0.8s" src="<?php echo e(asset('assets/image/printer.svg')); ?>" alt="" style="right:50%;position: absolute;bottom:0px;">
          </div>
        </div>
      </div>
    </div>
  </section>

</div>
<script src=" <?php echo e(asset('js/particles.min.js')); ?>"></script>
<script src=" <?php echo e(asset('js/app_animation.js')); ?>"></script>

<section id="features" class="section-bg">
  <div class="container mt-3">

    <div class="row feature-item ">
      <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
        <img src="<?php echo e(asset('assets/image/usaha.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0 order-2 order-lg-1">
        <h2>Mendukung setiap Usaha Anda</h2>
        <p>
          Berbagai jenis usaha mulai dari warung, toko, barbershop, kedai, restoran hingga penginapan, semua bisa kamu
          kelola dengan kuitansiku, dengan 3 langkah mudah kamu bisa langsung mulai berjualan.
        </p>
      </div>
    </div>
    <div class="row feature-item">
      <div class="col-lg-6 wow fadeInUp">
        <img src="<?php echo e(asset('assets/image/aman.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0">
        <h2>Pembayaran yang Aman dan Gampang</h2>
        <p>
          Kami mengerti kebutuhan akan kecepatan dan kemudahan bertransaksi oleh karena itu kami juga menyediakan
          pembayaran non-tunai melalui uang elektronik. sehingga transaksi tidak ribet tanpa menghitung refund.
        </p>
      </div>
    </div>
    <div class="row feature-item ">
      <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
        <img src="<?php echo e(asset('assets/image/transaksi.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0 order-2 order-lg-1">
        <h2>Bukti Transaksi yang Ramah Lingkungan</h2>
        <p>
          Tanda telah melakukan transaksi kepada konsumen itu sangatlah penting, sebab itu diberikannya bukti
          transaksi (nota), oleh sebab itu kuitansiku dapat memberikan bukti transaksi melalui aplikasi chat digital
        seperti Whatsapp, Email, dll. </p>
      </div>
    </div>
    <div class="row feature-item">
      <div class="col-lg-6 wow fadeInUp">
        <img src="<?php echo e(asset('assets/image/informasi.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0">
        <h2>Pencatatan Informasi</h2>
        <p>
          Analisis data yang akurat pada setiap informasi yang didapat, seperti penjualan, presensi karyawan, dan stock
          barang semua dapat terdata dalam sistem. Sehingga membantu dalam memanajemen karyawan, keuangan, dan barang.
        </p>
      </div>
    </div>
    <div class="row feature-item ">
      <div class="col-lg-6 wow fadeInUp order-1 order-lg-2">
        <img src="<?php echo e(asset('assets/image/internet.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0 order-2 order-lg-1">
        <h2>Tetap berkerja walau Internet padam</h2>
        <p>
          Kami sedih apabila internet anda mati, oleh sebab itu kami menyematkan penyimpanan sementara pada komputer
          yang aktif apabila Internet tiba-tiba putus, kemudian
          mengunggahnya setelah internet kembali menyala.
        </p>
      </div>
    </div>
    <div class="row feature-item">
      <div class="col-lg-6 wow fadeInUp">
        <img src="<?php echo e(asset('assets/image/kasbon.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0">
        <h2>Catatan Kasbon agar Usahamu tetap Lancar
        </h2>
        <p>
          Report kegiatan usahamu disajikan dalam tampilan yang nyaman dan dengan hasil yang akurat dan dapat di atur
          untuk laporan jangka waktu tertentu.
        </p>
      </div>
    </div>
  </div>
</section>
<?php echo $__env->make('menu.testimoni', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="download">
  <div class="container mt-3">
    <header class="section-header"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <h3>Download</h3>
    </header>
    <div class="row feature-item">
      <div class="col-lg-6 phone-img fadeInUp">
        <img src="<?php echo e(asset('assets/image/download.svg')); ?>" class="img-fluid" alt="">
      </div>
      <div class="col-lg-6 pt-lg-0">
        <h2>Permudah Oprasional anda menggunakan Aplikasi</h2>
        <p>
            jadikan kuitansiku berada di gengaman anda , segera download dan rasakan featurnya </p>
        <div class="row-lg-6 image-data">
          <a href=""> <img src="<?php echo e(asset('assets/image/apk.svg')); ?>" alt=""></a>
          <a href=""><img src="<?php echo e(asset('assets/image/ios.svg')); ?>" alt=""></a>
        </div>
      </div>
    </div>
  </section>

  <section id="contact" class="section-bg">
    <header class="container section-header">
      <h3>Customer Service</h3>
      <p>untuk meningkatkan layanan, kami akan selalu siap sedia mendengar tanggapan kritik serta saran kamu dengan cara mengisikan form dibawah ini</p>
    </header>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 wow fadeInUp">
          <img src="<?php echo e(asset('assets/image/contact.svg')); ?>" class="img-fluid" alt="">
        </div>

        <form action="" method="post" role="form" class="contactForm">
          <div class="form-group">
            <input type="text" class="form-control" name="nama" id="exampleInputEmail1" aria-describedby="emailHelp"
            placeholder="Name">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" name="email" id="email" placeholder="Email" data-rule="email"
            data-msg="Please enter a valid email" />
            <div class="validation"></div>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4"
            data-msg="Please enter at least 8 chars of subject" />
            <div class="validation"></div>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="5" data-rule="required"
            data-msg="Please write something for us" placeholder="Message"></textarea>
            <div class="validation"></div>
          </div>

          <button onclick="kirim()" type="button" class="btn btn-primary">Send Message</button>
          <script>
          function kirim(){
        alert("bisa diclick");
        var nama = $("[name = 'nama']").val();
		var email = $("[name = 'email']").val();
		var subject = $("[name = 'subject]").val();
		var pesan = $("[name = 'message']").val();
			$.ajax({
			type : "POST",
			data :"namasnd="+nama+"emailsnd="+email+"subjectsnd="+subject+"pesansnd="+pesan+,
			url : "/kirim",
			success : function(data)
			{
			    $("input").val("");
				$("textarea").val("");
				alert("pasanmu berhasil dikirim");
			},
			error: function()
			{
				alert("oops, ada yang salah, tetap tenang");
			}

		});
		$.ajax({
			type : "POST",
			data :"namasnd="+nama+"emailsnd="+email+"subjectsnd="+subject+"pesansnd="+pesan+,
			url : "kirim",
			success : function(data)
			{
			    $("input").val("");
				$("textarea").val("");
				alert("pasanmu berhasil dikirim");
			},
			error: function()
			{
				alert("oops, ada yang salah, tetap tenang");
			}

		});
    }
          </script>

        </form>

      </div>
    </div>
  </section>

  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-6 footer-info">
            <h3>Kuitansiku</h3>
            <p>Aplikasi Kasir Point of Sale yang sederhana dan dapat diandalkan
              karya anak-anak bangsa dan memiliki beragam fitur untuk
              membantu kinerja Anda sehingga membuat bisnis anda
              maju dan berkembang.

            </p>
            <img src="<?php echo e(asset('assets/image/100.svg')); ?>" alt="">
          </div>
          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Produk</h4>
            <ul>
              <li><a href="team">Our Team</a></li>
              <li><a href="about">About us</a></li>
              <li><a href="privacy">Privacy policy</a></li>
              <li><a href="support">Support</a></li>
              <li><a href="Feedback">Feedback</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Connect with Us</h4>
            <p>
              Email : admin.mailer@kuitansiku.com
            </p>
            <p>
              Phone : +62 8215 444 111 9
            </p>

            <div class="social-links">
              <a target="blank" href="https://aboutme.google.com/u/0/?referer=gplus" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a target="blank" href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a target="blank" href="https://www.instagram.com/kutansiku/" class="instagram"><i class="fa fa-instagram"></i></a>
              <a target="blank" href="#" class="twitter"><i class="fa fa-twitter"></i></a>
            </div>

          </div>
          <div class="container">
            <div class="copyright">
              Copyright &copy; 2019 <strong>Kuitansiku</strong>
            </div>
            <div class="credits">
            </div>
          </div>
        </div>
      </div>


    </footer>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\main_laravel\resources\views/menu/home.blade.php ENDPATH**/ ?>