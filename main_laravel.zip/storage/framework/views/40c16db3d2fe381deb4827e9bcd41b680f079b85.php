<?php $__env->startSection('title', 'Halaman Tidak Ditemukan'); ?>

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/404.css')); ?>" rel="stylesheet">

<div class="container mt-3">
    <header class="section-header">
        <h1>404</h1>
    </header>
    <div class="col wow fadeInUp pt-lg-0">
        <h5>ERROR</h4>
            <p>Maaf Halaman yang anda cari tidak ditemukan</p>
            <div class="img-center">
                <img src="<?php echo e(asset('assets/image/404 cat.svg')); ?>" alt="">
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\main_laravel\resources\views/errors/404.blade.php ENDPATH**/ ?>