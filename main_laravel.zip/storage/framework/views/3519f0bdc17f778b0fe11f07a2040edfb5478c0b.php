
<div class="ftr">
	<div style="background:#f5f5f5 ;color: #a0a0a0;font-size: 13px;">
		<div class="container">
			<div class="row">
				<div class="col-md-4 ftr-prp">
					<p><span style="color: orange;font-weight: bold;">Kuitansiku.co.id</span><br>
					adalah apikasi Point Of Sale karya anak bangsa yang simpel andal dan memiliki beragam fitur yang membantu kinerja anda sehingga membuat usaha anda semakin maju dan berkembang.</p>
					segera download & instal aplikasinya untuk Android atau I-Phone <a href="#"><img src="../img/playstore.png"></a><a href="#"><img src="../img/appstore.png"></a>.
				</div>
				<div class="col-md-4 ftr-prp">
					<div style="border-bottom: 1px solid #e0e0e0;text-align: center;margin-bottom: 20px">
						<b style="color: #999">Follow dan dapatkan info terbaru kami</b>
					</div>
					<div class="text-center social">
						<a href="" class="hvr-pulse-grow"><i class=" fab fa-facebook-f"></i></a>
						<a href="" class="hvr-pulse-grow"><i class=" fab fa-instagram"></i></a>
						<a href="" class="hvr-pulse-grow"><i class=" fab fa-twitter"></i></a>
					</div>
				</div>
				<div class="col-md-4 ftr-prp" style="text-align: right;">
					
					
					<div class="row ftr_ket">
						<div class="col-md-6">
						     <center> 
						     <div><img src="../img/indonesia.png" class="indonesia"></div>
						    <a target="blank" href="https://www.instagram.com/rochimmuhammad/"><div style="padding:20px">this site develop by m. nur rochim</div></a>
						    </center>
						    </div>
						<div class="col-md-6">
					        <b>bantuan</b>
        					<br>hubungi kami<br>
        					<a href="#">08215-444-111-9</a><br>
        					<a href="#">admin.mailer@kuitansiku.com</a><br>
        					<a href="#">buku panduan</a><br>
        					<a href="#">video panduan</a>
				        </div>
					</div>
				
				</div>

			</div>
		</div>	
		<div style="display: block;background: #ededed;padding-top: 20px">
			<center>
				<div>
					<h4>Anda perlu bantuan?</h4>
					<a class="hvr-float-shadow" href="#">
						<img src="../img/chat1.png" width="100x" style="margin: 20px;opacity: 0.9">
					</a>
					<p style="margin: 10px">Team kami selalu siap membantu anda terkait masalah <br>sistem, panduan, permohonan, integrasi, dan pertanyaan lainnya</p>
				</div>
				<div style="border-top: solid 1px grey;background: #15183a">
					<div style="text-align:center;color: #888;">Copyright <div style="font-size: 20px;display: inline;">&copy;</div> 2019-KuitansiKU</div>
				</div>
			</center>		
		</div>
	</div>


</div>
<?php /**PATH C:\xampp\htdocs\laravel\main_laravel\resources\views/ServiceLogin/footer.blade.php ENDPATH**/ ?>