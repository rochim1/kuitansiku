<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_setting extends Model
{
    //
}
